package com.adecco.libro.libro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibroApplicationTests {

	@Test
	void contextLoads() {
	}

}

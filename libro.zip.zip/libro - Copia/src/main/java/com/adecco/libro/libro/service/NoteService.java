package com.adecco.libro.libro.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adecco.libro.libro.model.Note;
import com.adecco.libro.libro.repository.NoteRepository;

@Service
public class NoteService {

	@Autowired
	NoteRepository noteRepository;

	public List<Note> getNote() {

		return noteRepository.findAll();

	}

	
	public Optional<Note> getNotaById(int id){
		return noteRepository.findById(id);
	}
	 
	
	public List<Note> getNotaByAutore(String autore){
		return noteRepository.findOne();
	}
	
	
}

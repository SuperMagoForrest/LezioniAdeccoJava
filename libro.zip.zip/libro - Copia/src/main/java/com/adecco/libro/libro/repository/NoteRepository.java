package com.adecco.libro.libro.repository;

import java.util.Collection;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.adecco.libro.libro.model.Note;

@Repository
public interface NoteRepository extends JpaRepository<Note, Integer> {
	@Query(
			  value = "SELECT * FROM  Nota WHERE id = ", 
			  nativeQuery = true)
			Collection<Note> findAllActiveUsersNative();

	List<Note> findOne();
}
